document.addEventListener("keypress",(Event) =>{
    
    Event.key =="e" || Event.key =="q" || Event.key =="u" || Event.key =="a" || Event.key =="l" ? console.log("equal") : console.log("notequal");
});
